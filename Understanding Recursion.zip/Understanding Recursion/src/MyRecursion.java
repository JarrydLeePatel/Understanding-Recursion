import java.util.Scanner;


//In this algorithm we look at the simple way of doing recursion..
//IG: Jarrydleepatel


public class MyRecursion {

	private static long factorial(int n) 
	{
		
		if (n == 1)
		return 1;
		else
		return n * factorial(n-1);
		}

	
	public static void main(String[] args) {
		MyRecursion a = new MyRecursion();
		System.out.println("Enter a Number between 1-10");
		Scanner input = new Scanner(System.in);
		int number = input.nextInt();
		while(number<1||number>11 ) {
			
		System.out.println("Number out of bounds");	
		System.out.println("Enter a new Number between 1-10");
		
		number = input.nextInt();
		}
		
		System.out.print("Thank you, The factorial of "+number+" is :");
		System.out.print(a.factorial(number));
		
	}
}

